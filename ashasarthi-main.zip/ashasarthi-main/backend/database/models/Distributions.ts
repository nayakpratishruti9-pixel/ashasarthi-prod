import {
  BelongsTo,
  Column,
  DataType,
  ForeignKey,
  Model,
  PrimaryKey,
  Table,
} from "sequelize-typescript";

import Awcs from "./Awcs";

@Table({
  timestamps: true,
  tableName: "distributions",
  modelName: "Distributions",
})
class Distributions extends Model {
  @PrimaryKey
  @Column({
    type: DataType.UUID,
    defaultValue: DataType.UUIDV4,
    allowNull: false,
  })
  declare id: string;

  // Anganwadi Center
  @ForeignKey(() => Awcs)
  @Column({
    type: DataType.UUID,
    allowNull: true,
  })
  declare awc_id: string;

  @BelongsTo(() => Awcs)
  declare awc: Awcs;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  declare supply_name: string;

  // Person receiving the supply
  @Column({
    type: DataType.STRING,
    allowNull: true,
  })
  declare beneficiary_name: string;

  // Ward
  @Column({
    type: DataType.STRING,
    allowNull: true,
  })
  declare ward_no: string;

  // Quantity distributed
  @Column({
    type: DataType.DECIMAL(10, 2),
    allowNull: false,
  })
  declare quantity: number;

  // Unit
  @Column({
    type: DataType.ENUM(
      "PIECES",
      "KG",
      "LITRES",
      "PACKETS",
      "BOTTLES",
      "DOSES",
      "OTHER"
    ),
    allowNull: false,
  })
  declare unit: string;

  // Date/time of distribution
  @Column({
    type: DataType.DATE,
    allowNull: false,
    defaultValue: DataType.NOW,
  })
  declare distributed_at: Date;

  // Optional notes
  @Column({
    type: DataType.TEXT,
    allowNull: true,
  })
  declare remarks: string | null;
}

export default Distributions;