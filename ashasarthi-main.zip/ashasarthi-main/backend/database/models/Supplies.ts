import {
  Column,
  DataType,
  ForeignKey,
  Model,
  PrimaryKey,
  Table,
} from "sequelize-typescript";

import User from "./User";

@Table({
  timestamps: true,
  tableName: "supplies",
  modelName: "Supplies",
})
class Supplies extends Model {
  @PrimaryKey
  @Column({
    type: DataType.UUID,
    defaultValue: DataType.UUIDV4,
    allowNull: false,
  })
  declare id: string;

  @ForeignKey(() => User)
  @Column({
    type: DataType.UUID,
    allowNull: false,
  })
  declare creator_id: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  declare item_name: string;

  @Column({
    type: DataType.ENUM(
      "PIECES",
      "KG",
      "LITRES",
      "PACKETS",
      "BOTTLES",
      "OTHER"
    ),
    allowNull: false,
  })
  declare unit: string;

  @Column({
    type: DataType.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 0,
  })
  declare available_quantity: number;

  @Column({
    type: DataType.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 10,
  })
  declare low_stock_threshold: number;
}

export default Supplies;