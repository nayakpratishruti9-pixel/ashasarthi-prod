import { Table, Model, DataType, PrimaryKey, Column } from "sequelize-typescript";

@Table({
    timestamps: true,
    tableName: "users",
    modelName: "User",
})

class User extends Model {
    @PrimaryKey
    @Column({
        type: DataType.UUID,
        defaultValue: DataType.UUIDV4,
        allowNull: false,

    })
    declare id: string;

    @Column({
        type: DataType.STRING,
        allowNull: true,
    })
    declare name: string;

    @Column({
        type: DataType.STRING,
        allowNull: false,
        unique: true,
    })
    declare email: string;

    @Column({
        type: DataType.STRING,
        allowNull: true,
    })
    declare phone: string;

    @Column({
        type: DataType.STRING,
        allowNull: false,
    })
    declare password_hash: string;

    @Column({
        type: DataType.ENUM("admin", "asha", "anm", "awcs" ),
        allowNull: false,
        defaultValue: "asha",
    })
    declare role: string;
     
}

export default User;