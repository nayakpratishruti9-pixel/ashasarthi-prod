import { Sequelize } from "sequelize-typescript";
import pg from "pg";

import User from "./models/User";
import Supplies from "./models/Supplies";
import Distributions from "./models/Distributions";
import Awcs from "./models/Awcs";

let sequelize: Sequelize | null = null;

export function getSequelize(): Sequelize {
if (sequelize) return sequelize;

const requiredEnv = [
"DATABASE_NAME",
"DATABASE_USERNAME",
"DATABASE_PASSWORD",
"DATABASE_HOST",
] as const;

for (const key of requiredEnv) {
if (!process.env[key]) {
throw new Error(`Missing required environment variable: ${key}`);
}
}

const port = Number(process.env.DATABASE_PORT || "6543");

if (!Number.isInteger(port) || port < 1 || port > 65535) {
throw new Error("DATABASE_PORT must be a valid port number");
}

sequelize = new Sequelize({
database: process.env.DATABASE_NAME!,
dialect: "postgres",
dialectModule: pg,
username: process.env.DATABASE_USERNAME!,
password: process.env.DATABASE_PASSWORD!,
host: process.env.DATABASE_HOST!,
port,
logging: false,
dialectOptions: {
ssl: process.env.NODE_ENV === "production"
? { require: true, rejectUnauthorized: true }
: undefined,
},
});

sequelize.addModels([User, Supplies, Awcs, Distributions]);

return sequelize;
}

export { User, Supplies, Awcs, Distributions };
