/**
 * Offline Test Page
 * Tests all offline functionality
 */

'use client';

import { useState, useEffect } from 'react';
import {
  CheckCircle,
  XCircle,
  Loader,
  Wifi,
  WifiOff,
  Database,
  FileText,
  Navigation,
} from 'lucide-react';
import { useOnlineStatus } from '@/hooks/useOffline';
import {
  initDB,
  getDashboardData,
  saveDashboardItem,
  getSetting,
  saveSetting,
} from '@/lib/db';

type TestResult = 'pending' | 'running' | 'passed' | 'failed';

interface Test {
  name: string;
  status: TestResult;
  message?: string;
}

export default function OfflineTestPage() {
  const isOnline = useOnlineStatus();
  const [tests, setTests] = useState<Test[]>([
    { name: 'Network Detection', status: 'pending' },
    { name: 'IndexedDB Initialization', status: 'pending' },
    { name: 'Write to IndexedDB', status: 'pending' },
    { name: 'Read from IndexedDB', status: 'pending' },
    { name: 'Service Worker Registration', status: 'pending' },
    { name: 'Page Navigation', status: 'pending' },
  ]);
  const [overallStatus, setOverallStatus] = useState<'idle' | 'running' | 'complete'>('idle');

  const updateTest = (index: number, status: TestResult, message?: string) => {
    setTests((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], status, message };
      return updated;
    });
  };

  const runTests = async () => {
    setOverallStatus('running');

    // Test 1: Network Detection
    updateTest(0, 'running');
    await sleep(500);
    if (typeof navigator !== 'undefined' && 'onLine' in navigator) {
      updateTest(0, 'passed', `Status: ${isOnline ? 'Online' : 'Offline'}`);
    } else {
      updateTest(0, 'failed', 'Navigator API not available');
    }

    // Test 2: IndexedDB Initialization
    updateTest(1, 'running');
    try {
      await initDB();
      updateTest(1, 'passed', 'Database initialized successfully');
    } catch (error) {
      updateTest(1, 'failed', `Error: ${error}`);
      setOverallStatus('complete');
      return;
    }

    // Test 3: Write to IndexedDB
    updateTest(2, 'running');
    try {
      const testItem = {
        id: 'test-' + Date.now(),
        title: 'Test Entry',
        description: 'Offline test data',
        status: 'test',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      await saveDashboardItem(testItem);
      updateTest(2, 'passed', 'Data written successfully');
    } catch (error) {
      updateTest(2, 'failed', `Error: ${error}`);
    }

    // Test 4: Read from IndexedDB
    updateTest(3, 'running');
    try {
      const data = await getDashboardData();
      updateTest(3, 'passed', `Retrieved ${data.length} items`);
    } catch (error) {
      updateTest(3, 'failed', `Error: ${error}`);
    }

    // Test 5: Service Worker
    updateTest(4, 'running');
    await sleep(500);
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.getRegistration();
        if (registration) {
          updateTest(4, 'passed', 'Service worker registered');
        } else {
          updateTest(4, 'failed', 'Service worker not registered (may need production build)');
        }
      } catch (error) {
        updateTest(4, 'failed', `Error: ${error}`);
      }
    } else {
      updateTest(4, 'failed', 'Service workers not supported');
    }

    // Test 6: Page Navigation
    updateTest(5, 'running');
    await sleep(500);
    if (typeof window !== 'undefined') {
      updateTest(5, 'passed', 'Navigation API available');
    } else {
      updateTest(5, 'failed', 'Navigation not available');
    }

    setOverallStatus('complete');
  };

  const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

  const getStatusIcon = (status: TestResult) => {
    switch (status) {
      case 'pending':
        return <div className="w-5 h-5 rounded-full border-2 border-gray-300" />;
      case 'running':
        return <Loader className="w-5 h-5 text-blue-500 animate-spin" />;
      case 'passed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-500" />;
    }
  };

  const allTestsPassed = tests.every((t) => t.status === 'passed');
  const someTestsFailed = tests.some((t) => t.status === 'failed');

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Offline Functionality Test
          </h1>
          
          <div className="flex items-center gap-2 mb-4">
            {isOnline ? (
              <>
                <Wifi className="w-5 h-5 text-green-600" />
                <span className="text-sm text-green-600 font-medium">Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-5 h-5 text-yellow-600" />
                <span className="text-sm text-yellow-600 font-medium">Offline</span>
              </>
            )}
          </div>

          <p className="text-gray-600">
            This page tests all offline functionality of the application.
            For best results, run tests while offline.
          </p>
        </div>

        {/* Test Controls */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <button
            onClick={runTests}
            disabled={overallStatus === 'running'}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold py-3 px-6 rounded-lg transition"
          >
            {overallStatus === 'running' ? 'Running Tests...' : 'Run Offline Tests'}
          </button>
        </div>

        {/* Test Results */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Test Results</h2>
          
          <div className="space-y-4">
            {tests.map((test, index) => (
              <div
                key={index}
                className="flex items-start gap-4 p-4 rounded-lg border border-gray-200"
              >
                <div className="flex-shrink-0 mt-1">
                  {getStatusIcon(test.status)}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{test.name}</h3>
                  {test.message && (
                    <p className="text-sm text-gray-600 mt-1">{test.message}</p>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Overall Status */}
          {overallStatus === 'complete' && (
            <div
              className={`mt-6 p-4 rounded-lg ${
                allTestsPassed
                  ? 'bg-green-50 border border-green-200'
                  : someTestsFailed
                  ? 'bg-red-50 border border-red-200'
                  : 'bg-yellow-50 border border-yellow-200'
              }`}
            >
              <p
                className={`font-semibold ${
                  allTestsPassed
                    ? 'text-green-800'
                    : someTestsFailed
                    ? 'text-red-800'
                    : 'text-yellow-800'
                }`}
              >
                {allTestsPassed
                  ? '✓ All tests passed! App is fully offline-ready.'
                  : someTestsFailed
                  ? '✗ Some tests failed. Check the results above.'
                  : '⚠ Tests completed with warnings.'}
              </p>
            </div>
          )}
        </div>

        {/* Manual Tests */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Manual Tests</h2>
          
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <Navigation className="w-5 h-5 text-blue-600 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900">Page Navigation</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Navigate to different pages while offline to verify they load correctly.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <FileText className="w-5 h-5 text-blue-600 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900">Form Submission</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Try adding data in the Dashboard while offline.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Database className="w-5 h-5 text-blue-600 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900">Data Persistence</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Reload the page while offline - data should persist.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
          <h3 className="font-semibold text-blue-900 mb-2">Testing Instructions</h3>
          <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
            <li>Open Chrome DevTools (F12)</li>
            <li>Go to Network tab</li>
            <li>Select "Offline" from throttling dropdown</li>
            <li>Click "Run Offline Tests" button</li>
            <li>Navigate to other pages to test manual functionality</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
