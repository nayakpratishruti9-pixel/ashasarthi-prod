/**
 * Settings Page - Fully Offline-Capable
 * All settings are stored in IndexedDB for offline access
 */

'use client';

import { useState, useEffect } from 'react';
import {
  Settings as SettingsIcon,
  Save,
  Trash2,
  Database,
  Wifi,
  WifiOff,
  Download,
  CheckCircle,
} from 'lucide-react';
import { useOnlineStatus, useInstallPrompt } from '@/hooks/useOffline';
import {
  getSetting,
  saveSetting,
  getAllSettings,
  clearAllData,
  seedSampleData,
} from '@/lib/db';

export default function SettingsPage() {
  const isOnline = useOnlineStatus();
  const { isInstallable, promptInstall } = useInstallPrompt();
  
  const [theme, setTheme] = useState('light');
  const [notifications, setNotifications] = useState(true);
  const [language, setLanguage] = useState('en');
  const [loading, setLoading] = useState(true);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  // Load settings from IndexedDB
  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const themeVal = await getSetting('theme');
      const notificationsVal = await getSetting('notifications');
      const languageVal = await getSetting('language');

      if (themeVal) setTheme(themeVal.value);
      if (notificationsVal) setNotifications(notificationsVal.value);
      if (languageVal) setLanguage(languageVal.value);
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = async () => {
    setSaveStatus('saving');
    
    try {
      await saveSetting('theme', theme);
      await saveSetting('notifications', notifications);
      await saveSetting('language', language);
      
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings');
      setSaveStatus('idle');
    }
  };

  const handleClearData = async () => {
    if (!confirm('Are you sure you want to clear all offline data? This cannot be undone.')) {
      return;
    }

    try {
      await clearAllData();
      alert('All offline data has been cleared');
      window.location.reload();
    } catch (error) {
      console.error('Error clearing data:', error);
      alert('Failed to clear data');
    }
  };

  const handleSeedData = async () => {
    try {
      await seedSampleData();
      alert('Sample data has been loaded');
      window.location.reload();
    } catch (error) {
      console.error('Error seeding data:', error);
      alert('Failed to seed data');
    }
  };

  const handleInstall = async () => {
    const success = await promptInstall();
    if (success) {
      alert('App installed successfully!');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <SettingsIcon className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
          </div>
          
          {/* Online/Offline Status */}
          <div className="flex items-center gap-2 mt-4">
            {isOnline ? (
              <>
                <Wifi className="w-5 h-5 text-green-600" />
                <span className="text-sm text-green-600 font-medium">Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-5 h-5 text-yellow-600" />
                <span className="text-sm text-yellow-600 font-medium">Offline Mode</span>
              </>
            )}
          </div>
        </div>

        {/* App Settings */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">App Settings</h2>
          
          {/* Theme Setting */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Theme
            </label>
            <select
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="light">Light</option>
              <option value="dark">Dark</option>
              <option value="auto">Auto</option>
            </select>
          </div>

          {/* Notifications Setting */}
          <div className="mb-6">
            <label className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">
                Enable Notifications
              </span>
              <input
                type="checkbox"
                checked={notifications}
                onChange={(e) => setNotifications(e.target.checked)}
                className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
              />
            </label>
          </div>

          {/* Language Setting */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Language
            </label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="en">English</option>
              <option value="hi">हिन्दी</option>
              <option value="or">ଓଡ଼ିଆ</option>
            </select>
          </div>

          {/* Save Button */}
          <button
            onClick={handleSaveSettings}
            disabled={saveStatus === 'saving'}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition"
          >
            {saveStatus === 'saving' ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-white"></div>
                <span>Saving...</span>
              </>
            ) : saveStatus === 'saved' ? (
              <>
                <CheckCircle className="w-5 h-5" />
                <span>Saved!</span>
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                <span>Save Settings</span>
              </>
            )}
          </button>
        </div>

        {/* PWA Installation */}
        {isInstallable && (
          <div className="bg-gradient-to-r from-purple-500 to-blue-600 rounded-lg shadow-md p-6 mb-6 text-white">
            <h2 className="text-xl font-semibold mb-2">Install App</h2>
            <p className="mb-4 text-purple-100">
              Install this app on your device for faster access and offline functionality
            </p>
            <button
              onClick={handleInstall}
              className="bg-white text-purple-600 font-semibold py-2 px-6 rounded-lg hover:bg-purple-50 transition flex items-center gap-2"
            >
              <Download className="w-5 h-5" />
              <span>Install Now</span>
            </button>
          </div>
        )}

        {/* Data Management */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Data Management</h2>
          
          <div className="space-y-4">
            {/* Seed Sample Data */}
            <button
              onClick={handleSeedData}
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition"
            >
              <Database className="w-5 h-5" />
              <span>Load Sample Data</span>
            </button>

            {/* Clear Data */}
            <button
              onClick={handleClearData}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition"
            >
              <Trash2 className="w-5 h-5" />
              <span>Clear All Data</span>
            </button>
          </div>

          <p className="text-xs text-gray-500 mt-4">
            All data is stored locally in your browser's IndexedDB. Clearing data will remove all offline information.
          </p>
        </div>

        {/* Info Section */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
          <h3 className="font-semibold text-blue-900 mb-2">Offline-First App</h3>
          <p className="text-sm text-blue-800">
            This app works completely offline. All data is stored locally on your device. 
            Changes are saved immediately and will sync when you're back online.
          </p>
        </div>
      </div>
    </div>
  );
}
