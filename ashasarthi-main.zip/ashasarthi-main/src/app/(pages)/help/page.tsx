"use client";

import { FormEvent, useState } from "react";
import {
  BookOpen,
  CheckCircle2,
  ChevronDown,
  ClipboardList,
  HeartPulse,
  Mail,
  MapPin,
  Package,
  Phone,
  Send,
  ShieldCheck,
  Users,
  type LucideIcon,
} from "lucide-react";

const faqs = [
  {
    question: "What is AshaSarthi?",
    answer:
      "AshaSarthi is a healthcare management workspace that helps ASHA workers organize community records, track supplies, and keep routine field work accessible in one place.",
  },
  {
    question: "How do I record a supply distribution?",
    answer:
      "Open Dashboard, choose Add, select a supply, enter the beneficiary and ward details, then save the record. The available inventory is updated when the distribution is recorded.",
  },
  {
    question: "Can I use the application without an internet connection?",
    answer:
      "Some application preferences and offline features are available without a connection. Records that need to be synchronized with the server require you to reconnect before saving.",
  },
  {
    question: "How can I report a problem?",
    answer:
      "Use the contact form on this page and include the page name, what you were trying to do, and any error message you saw. This helps the support team investigate quickly.",
  },
];

const features: Array<{ icon: LucideIcon; title: string; description: string }> = [
  {
    icon: ClipboardList,
    title: "Dashboard",
    description: "Record beneficiary visits and supply distributions in one workspace.",
  },
  {
    icon: Package,
    title: "Supply tracking",
    description: "Keep inventory quantities and low-stock items visible.",
  },
  {
    icon: Users,
    title: "Community care",
    description: "Organize essential information for the communities you serve.",
  },
  {
    icon: ShieldCheck,
    title: "Private by design",
    description: "Use authenticated access to keep operational records protected.",
  },
];

const HelpPage = () => {
  const [openFaq, setOpenFaq] = useState(0);
  const [formStatus, setFormStatus] = useState<"idle" | "invalid">("idle");

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get("name") ?? "").trim();
    const email = String(form.get("email") ?? "").trim();
    const subject = String(form.get("subject") ?? "").trim();
    const message = String(form.get("message") ?? "").trim();

    if (!name || !email || !subject || !message) {
      setFormStatus("invalid");
      return;
    }

    const body = `Name: ${name}\nEmail: ${email}\n\n${message}`;
    window.location.href = `mailto:support@ashasarthi.org?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <main className="min-h-[calc(100vh-64px)] bg-gradient-to-br from-orange-50 via-white to-orange-100">
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {features.map(({ icon: FeatureIcon, title, description }) => {
            return (
              <article key={title} className="rounded-2xl border border-orange-100 bg-white p-5 shadow-sm">
                <FeatureIcon className="h-6 w-6 text-orange-600" />
                <h2 className="mt-4 font-semibold text-gray-900">{title}</h2>
                <p className="mt-2 text-sm leading-6 text-gray-600">{description}</p>
              </article>
            );
          })}
        </div>

        <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_1.1fr]">
          <section className="rounded-2xl border border-orange-100 bg-white p-6 shadow-sm sm:p-8">
            <div className="flex items-center gap-3">
              <BookOpen className="h-6 w-6 text-orange-600" />
              <h2 className="text-xl font-bold text-gray-900">Frequently asked questions</h2>
            </div>
            <div className="mt-6 divide-y divide-orange-100">
              {faqs.map((faq, index) => (
                <div key={faq.question} className="py-4 first:pt-0 last:pb-0">
                  <button
                    type="button"
                    onClick={() => setOpenFaq(openFaq === index ? -1 : index)}
                    className="flex w-full items-center justify-between gap-4 text-left font-medium text-gray-900"
                    aria-expanded={openFaq === index}
                  >
                    <span>{faq.question}</span>
                    <ChevronDown className={`h-5 w-5 shrink-0 text-orange-500 transition-transform ${openFaq === index ? "rotate-180" : ""}`} />
                  </button>
                  {openFaq === index && (
                    <p className="mt-3 pr-6 text-sm leading-6 text-gray-600">{faq.answer}</p>
                  )}
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-2xl border border-orange-100 bg-white p-6 shadow-sm sm:p-8">
            <div className="flex items-center gap-3">
              <Mail className="h-6 w-6 text-orange-600" />
              <div>
                <h2 className="text-xl font-bold text-gray-900">Contact support</h2>
                <p className="mt-1 text-sm text-gray-600">We are here to help with questions and technical issues.</p>
              </div>
            </div>

            <form className="mt-6 space-y-4" onSubmit={handleSubmit} noValidate>
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="text-sm font-medium text-gray-700">
                  Name
                  <input name="name" type="text" required placeholder="Your name" className="mt-1.5 w-full rounded-lg border border-orange-200 px-3 py-2.5 text-sm outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-100" />
                </label>
                <label className="text-sm font-medium text-gray-700">
                  Email
                  <input name="email" type="email" required placeholder="you@example.com" className="mt-1.5 w-full rounded-lg border border-orange-200 px-3 py-2.5 text-sm outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-100" />
                </label>
              </div>
              <label className="block text-sm font-medium text-gray-700">
                Subject
                <input name="subject" type="text" required placeholder="How can we help?" className="mt-1.5 w-full rounded-lg border border-orange-200 px-3 py-2.5 text-sm outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-100" />
              </label>
              <label className="block text-sm font-medium text-gray-700">
                Message
                <textarea name="message" required rows={5} placeholder="Describe your question or issue..." className="mt-1.5 w-full resize-y rounded-lg border border-orange-200 px-3 py-2.5 text-sm outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-100" />
              </label>
              {formStatus === "invalid" && (
                <p className="text-sm text-red-600" role="alert">Please complete all fields before sending your message.</p>
              )}
              <button type="submit" className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-orange-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2">
                <Send className="h-4 w-4" />
                Open email draft
              </button>
            </form>
          </section>
        </div>

        <div className="mt-8 flex flex-col gap-4 rounded-2xl border border-orange-100 bg-white p-5 text-sm text-gray-600 shadow-sm sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2"><Mail className="h-4 w-4 text-orange-600" /> support@ashasarthi.org</div>
          <div className="flex items-center gap-2"><Phone className="h-4 w-4 text-orange-600" /> Support available during working hours</div>
          <div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-orange-600" /> Odisha, India</div>
        </div>
      </section>
    </main>
  );
};

export default HelpPage;
