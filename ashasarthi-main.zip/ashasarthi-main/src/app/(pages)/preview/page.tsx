"use client";
import React from 'react';
import { useTranslations } from 'next-intl';

// Define the type for a user's preview data
interface UserPreview {
  id: number;
  name: string;
  hypertensionRate: number;
  diabetesRate: number;
  advice: string;
}

const Preview: React.FC = () => {
  const t = useTranslations('preview');
  // Mock data for multiple users to be previewed
  const users: UserPreview[] = [
    {
      id: 1,
      name: 'Sthithi Dash',
      hypertensionRate: 140,
      diabetesRate: 180,
      advice: 'Advised to consult a cardiologist and an endocrinologist for a detailed check-up. Recommended daily walks and a diet low in sugar and salt. Follow-up visit in one month.',
    },
    {
      id: 2,
      name: 'Priya Sharma',
      hypertensionRate: 125,
      diabetesRate: 95,
      advice: 'Blood pressure and blood sugar are within a healthy range. Advised to maintain current diet and exercise routine. Regular check-ups are recommended.',
    },
    {
      id: 3,
      name: 'Anjali Desai',
      hypertensionRate: 155,
      diabetesRate: 110,
      advice: 'Blood pressure is elevated. Advised to reduce sodium intake and increase physical activity. Follow-up with a physician for medication review.',
    },
    {
      id: 4,
      name: 'Sanjay Kumar',
      hypertensionRate: 130,
      diabetesRate: 210,
      advice: 'Blood sugar is very high. Immediate consultation with an endocrinologist is necessary. Start a low-sugar diet and monitor blood sugar levels regularly.',
    },
  ];

  return (
    <div className="min-h-[calc(100vh-64px)] p-6 bg-gray-50 font-sans">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* User Preview Card Header */}
        <div className="bg-orange-500 rounded-2xl p-4 flex items-center justify-between shadow-lg text-white">
          <h2 className="text-xl font-semibold">{t('userPreview')}</h2>
        </div>

        {/* User Details Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {users.map((user) => (
            <div key={user.id} className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="space-y-4">
                {/* Name */}
                <div>
                  <p className="text-sm font-semibold text-gray-500 uppercase">{t('name')}</p>
                  <h3 className="text-2xl font-bold text-gray-900">{user.name}</h3>
                </div>

                {/* Rates */}
                <div className="flex flex-wrap gap-4">
                  <div>
                    <p className="text-sm font-semibold text-gray-500 uppercase">{t('hypertensionRate')}</p>
                    <span className={`text-xl font-bold ${user.hypertensionRate > 140 ? 'text-red-600' : 'text-green-600'}`}>
                      {user.hypertensionRate} mmHg
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-500 uppercase">{t('diabetesRate')}</p>
                    <span className={`text-xl font-bold ${user.diabetesRate > 125 ? 'text-red-600' : 'text-green-600'}`}>
                      {user.diabetesRate} mg/dL
                    </span>
                  </div>
                </div>

                {/* Advice for Further Consultancy */}
                <div>
                  <p className="text-sm font-semibold text-gray-500 uppercase mb-1">{t('adviceForConsultancy')}</p>
                  <p className="text-gray-700 leading-relaxed">
                    {user.advice}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Preview;
