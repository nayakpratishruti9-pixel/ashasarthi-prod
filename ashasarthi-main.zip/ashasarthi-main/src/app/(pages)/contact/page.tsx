
import React from "react";

const ContactPage = () => {
    return <div className="min-h-[calc(100vh-64px)]">
        

    </div>;
}

export default ContactPage;