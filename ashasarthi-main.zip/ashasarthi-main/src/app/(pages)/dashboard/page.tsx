"use client";
import { useState, useEffect } from "react";
import {
  User,
  Plus,
  Save,
  X,
  UserCheck,
  MapPin,
  Phone,
} from "lucide-react";
import { useTranslations } from "next-intl";
import Axios from "@/lib/api";
import { useSession } from "next-auth/react";

interface SupplyItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  threshold: number;
}

interface SupplyEntry {
  sno: number;
  id: string;
  date: string;
  suppliesName: string;
  quantity: number;
  unit: string;
  recipientName: string;
  wardNo: string;
}

type DistributionForm = {
  supplyId: string;
  suppliesName: string;
  quantity: number;
  unit: string;
  recipientName: string;
  wardNo: string;
};

const Dashboard = () => {
  const t = useTranslations('dashboard');
  const { data: session } = useSession();
  const [entries, setEntries] = useState<SupplyEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadEntries = async () => {
      try {
        const response = await Axios.get<Omit<SupplyEntry, "sno">[]>("/distributions");
        setEntries(response.data.map((entry, index) => ({ ...entry, sno: index + 1 })));
        setError(null);
      } catch {
        setError("Unable to load distribution records. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    void loadEntries();
  }, []);

  const [isAddingNew, setIsAddingNew] = useState(false);
  const [viewMode, setViewMode] = useState<"table" | "cards">("cards"); // Default to cards for mobile
  const [newEntry, setNewEntry] = useState<DistributionForm>({
    supplyId: "",
    suppliesName: "",
    quantity: 1,
    unit: "",
    recipientName: "",
    wardNo: "",
  });

  const ashaWorker = {
    name: session?.user?.name || "User",
    id: session?.user?.id || "Not available",
    role: session?.user?.role || "Worker",
    phone: session?.user?.phone || "Not available",
  };

  const [supplyOptions, setSupplyOptions] = useState<SupplyItem[]>([]);

  // Load and format supply options from inventory
  useEffect(() => {
    const loadSupplies = async () => {
      try {
        const response = await Axios.get<SupplyItem[]>("/supplies");
        setSupplyOptions(response.data);
      } catch {
        setError("Unable to load supplies. Please try again.");
      }
    };

    void loadSupplies();
  }, []);

  const handleAddNew = async () => {
    if (
      newEntry.supplyId &&
      newEntry.quantity > 0 &&
      newEntry.recipientName &&
      newEntry.wardNo
    ) {
      const supply = supplyOptions.find((item) => item.id === newEntry.supplyId);
      if (!supply || supply.quantity < newEntry.quantity) {
        setError("Not enough supply in stock.");
        return; // Not enough stock or other error
      }

      try {
        const updatedSupply = {
          ...supply,
          quantity: supply.quantity - newEntry.quantity,
        };
        await Axios.put(`/supplies?id=${encodeURIComponent(supply.id)}`, updatedSupply);
        const response = await Axios.post<Omit<SupplyEntry, "sno">>("/distributions", {
          supplyId: supply.id,
          unit: supply.unit,
          quantity: newEntry.quantity,
          recipientName: newEntry.recipientName,
          wardNo: newEntry.wardNo,
        });
        setEntries((current) => [
          { ...response.data, sno: 1 },
          ...current.map((entry) => ({ ...entry, sno: entry.sno + 1 })),
        ]);
        setSupplyOptions((current) =>
          current.map((item) => item.id === supply.id ? updatedSupply : item),
        );
        setNewEntry({ supplyId: "", suppliesName: "", quantity: 1, unit: "", recipientName: "", wardNo: "" });
        setIsAddingNew(false);
        setError(null);
      } catch {
        setError("Unable to save distribution. Please try again.");
      }
    }
  };

  const handleInputChange = (
    field: keyof DistributionForm,
    value: string | number
  ) => {
    setNewEntry((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  // Mobile Card View Component
  const EntryCard = ({ entry }: { entry: SupplyEntry }) => (
    <div className="bg-white rounded-lg shadow-md border border-orange-100 p-4 mb-4">
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center space-x-2">
          <span className="bg-orange-100 text-orange-800 text-xs font-semibold px-2 py-1 rounded-full">
            #{entry.sno}
          </span>
          <span className="text-xs text-gray-500">{entry.date}</span>
        </div>
        <div className="flex space-x-2">
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
          <span className="font-semibold text-gray-900">
            {entry.suppliesName} ({entry.quantity})
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center space-x-1">
            <UserCheck className="h-3 w-3 text-gray-400" />
            <span className="text-gray-700">{entry.recipientName}</span>
          </div>
          <div className="flex items-center space-x-1">
            <MapPin className="h-3 w-3 text-gray-400" />
            <span className="text-gray-700">{entry.wardNo}</span>
          </div>
          <div className="text-gray-600">{entry.unit}</div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100">
      <div className="px-3 py-4 max-w-4xl mx-auto">
        {/* Loading State */}
        {loading && (
          <div className="bg-white rounded-lg shadow-md p-8 text-center mb-4">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading data...</p>
          </div>
        )}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg p-3 mb-4 text-sm">
            {error}
          </div>
        )}

        {/* ASHA Worker Profile Card - Mobile Optimized */}
        <div className="bg-white rounded-xl shadow-lg border border-orange-100 p-4 mb-4">{!loading && (<div className="flex items-start space-x-3">{/* existing content */}
            <div className="h-12 w-12 bg-gradient-to-r from-orange-500 to-orange-600 rounded-full flex items-center justify-center flex-shrink-0">
              <User className="h-6 w-6 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-lg font-bold text-gray-900 truncate">
                {ashaWorker.name}
              </h2>
              <p className="text-orange-600 font-medium text-sm capitalize">
                {ashaWorker.role}
              </p>
              <div className="mt-2 space-y-1">
                <div className="flex items-center text-xs text-gray-600">
                  <span className="font-semibold mr-1">ID:</span>
                  <span className="truncate">{ashaWorker.id}</span>
                </div>
                <div className="flex items-center text-xs text-gray-600">
                  <Phone className="h-3 w-3 mr-1 flex-shrink-0" />
                  <span>+91 {ashaWorker.phone.slice(0, 4)}-{ashaWorker.phone.slice(4, 7)}-{ashaWorker.phone.slice(7)}</span>
                </div>
              </div>
            </div>
          </div>)}
        </div>

        {/* Header with View Toggle and Add Button */}
        <div className="bg-white rounded-xl shadow-lg border border-orange-100 mb-4">
          <div className="px-4 py-3 bg-gradient-to-r from-orange-500 to-orange-600 rounded-t-xl">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold text-white">{t('supplyRecords')}</h3>
              <button
                onClick={() => setIsAddingNew(true)}
                className="bg-white text-orange-600 px-3 py-2 rounded-lg font-medium text-sm hover:bg-orange-50 transition duration-200 flex items-center space-x-1"
              >
                <Plus className="h-4 w-4" />
                <span>{t('add')}</span>
              </button>
            </div>
          </div>

          {/* View Toggle - Mobile Friendly */}
          <div className="px-4 py-3 border-b border-orange-100">
            <div className="flex space-x-1 bg-orange-50 p-1 rounded-lg">
              <button
                onClick={() => setViewMode("cards")}
                className={`flex-1 py-2 px-3 text-sm font-medium rounded-md transition duration-200 cursor-pointer ${
                  viewMode === "cards"
                    ? "bg-white text-orange-600 shadow-sm"
                    : "text-gray-600 hover:text-orange-600"
                }`}
              >
                {t('cardView')}
              </button>
              <button
                onClick={() => setViewMode("table")}
                className={`flex-1 py-2 px-3 text-sm font-medium rounded-md transition duration-200 cursor-pointer ${
                  viewMode === "table"
                    ? "bg-white text-orange-600 shadow-sm"
                    : "text-gray-600 hover:text-orange-600"
                }`}
              >
                {t('tableView')}
              </button>
            </div>
          </div>

          {/* Add New Entry Form - Mobile Optimized */}
          {isAddingNew && (
            <div className="p-4 bg-orange-25 border-b border-orange-100">
              <h4 className="font-semibold text-gray-900 mb-3">
                {t('addNewEntry')}
              </h4>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="hidden">
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      {t('date')}
                    </label>
                    <input
                      type="date"
                      value={new Date().toISOString().split("T")[0]}
                      readOnly
                      className="w-full px-3 py-2 border border-orange-200 rounded-lg bg-gray-50 text-sm cursor-not-allowed"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      {t('wardNo')}
                    </label>
                    <input
                      type="text"
                      value={newEntry.wardNo}
                      onChange={(e) =>
                        handleInputChange("wardNo", e.target.value)
                      }
                      placeholder={t('wardNoPlaceholder')}
                      className="w-full px-3 py-2 border border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      {t('supplyName')}
                    </label>
                    <select
                      value={newEntry.supplyId}
                      onChange={(e) => {
                        const supply = supplyOptions.find((item) => item.id === e.target.value);
                        setNewEntry((current) => ({
                          ...current,
                          supplyId: e.target.value,
                          suppliesName: supply?.name ?? "",
                          unit: supply?.unit ?? "",
                        }));
                      }}
                      className="w-full px-3 py-2 border border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                    >
                      <option value="">{t('selectSupply')}</option>
                      {supplyOptions.map((supply) => (
                        <option key={supply.id} value={supply.id}>
                          {supply.name} ({supply.quantity} {supply.unit})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      {t('quantity')}
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={newEntry.quantity}
                      onChange={(e) =>
                        handleInputChange("quantity", Math.max(1, parseInt(e.target.value) || 1))
                      }
                      className="w-full px-3 py-2 border border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    {t('recipientName')}
                  </label>
                  <input
                    type="text"
                    value={newEntry.recipientName}
                    onChange={(e) =>
                      handleInputChange("recipientName", e.target.value)
                    }
                    placeholder={t('recipientNamePlaceholder')}
                    className="w-full px-3 py-2 border border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                  />
                </div>

                <div className="flex space-x-3 pt-2">
                  <button
                    onClick={handleAddNew}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg font-medium text-sm transition duration-200 flex items-center justify-center space-x-1"
                  >
                    <Save className="h-4 w-4" />
                    <span>{t('saveEntry')}</span>
                  </button>
                  <button
                    onClick={() => setIsAddingNew(false)}
                    className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded-lg font-medium text-sm transition duration-200 flex items-center justify-center space-x-1"
                  >
                    <X className="h-4 w-4" />
                    <span>{t('cancel')}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Data Display */}
        {viewMode === "cards" ? (
          // Mobile Card View
          <div>
            {entries.length > 0 ? (
              entries.map((entry) => (
                <EntryCard key={entry.sno} entry={entry} />
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p>{t('noEntries')}</p>
              </div>
            )}
          </div>
        ) : (
          // Table View (with horizontal scroll for mobile)
          <div className="bg-white rounded-xl shadow-lg border border-orange-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-orange-50">
                  <tr>
                    <th className="px-3 py-2 text-left text-xs font-medium text-orange-800 uppercase">
                      {t('sno')}
                    </th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-orange-800 uppercase">
                      {t('date')}
                    </th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-orange-800 uppercase">
                      {t('supply')}
                    </th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-orange-800 uppercase">
                      {t('name')}
                    </th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-orange-800 uppercase">
                      {t('wardNo')}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-orange-100">
                  {entries.map((entry) => (
                    <tr key={entry.sno} className="hover:bg-orange-25">
                      <td className="px-3 py-2 text-sm font-medium text-gray-900">
                        {entry.sno}
                      </td>
                      <td className="px-3 py-2 text-xs text-gray-500">
                        {entry.date}
                      </td>
                      <td className="px-3 py-2 text-xs text-gray-900">
                        {entry.suppliesName} (x{entry.quantity})
                      </td>
                      <td className="px-3 py-2 text-xs text-gray-900">
                        {entry.recipientName}
                      </td>
                      <td className="px-3 py-2 text-xs text-gray-500">
                        {entry.wardNo}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Footer Stats - Mobile Optimized */}
        <div className="mt-4 bg-white rounded-xl shadow-lg border border-orange-100 p-4">
          <div className="flex justify-between items-center text-sm text-gray-600">
            <span>{t('total')}: {entries.length} {t('entries')}</span>
            <span className="text-xs">
              {t('updated')}: {new Date().toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
