"use client";
import React, { useState } from "react";

// Define the type for an NCD data item
interface NCDItem {
  id: number;
  subCenter: string;
  name: string;
  adharNo: string;
  diseases: string[];
  prescribed: boolean;
}

const NCDData: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState("");

  // Mock data with the defined type
  const [data] = useState<NCDItem[]>([
    {
      id: 1,
      subCenter: "Hatpada",
      name: "Ramesh Singh",
      adharNo: "xxxx xxxx 9012",
      diseases: ["Hypertension", "Diabetes"],
      prescribed: true,
    },
    {
      id: 2,
      subCenter: "Hatpada",
      name: "Priya Sharma",
      adharNo: "xxxx xxxx 0123",
      diseases: ["Heart Disease"],
      prescribed: false,
    },
    {
      id: 3,
      subCenter: "Hatpada",
      name: "Anjali Desai",
      adharNo: "xxxx xxxx 1234",
      diseases: ["Hypertension"],
      prescribed: true,
    },
    {
      id: 4,
      subCenter: "Gandhinagar",
      name: "Sanjay Kumar",
      adharNo: "xxxx xxxx 2345",
      diseases: ["Diabetes", "Heart Disease"],
      prescribed: true,
    },
    {
      id: 5,
      subCenter: "Brahminpada",
      name: "Deepa Verma",
      adharNo: "xxxx xxxx 3456",
      diseases: [],
      prescribed: false,
    },
  ]);

  const filteredData = data.filter((item) => {
    const query = searchQuery.trim().toLowerCase();

    if (!query) {
      return true;
    }

    return [
      item.subCenter,
      item.name,
      item.adharNo,
      ...item.diseases,
    ].some((value) => value.toLowerCase().includes(query));
  });

  return (
    <div className="min-h-[calc(100vh-64px)] p-6 bg-gray-50 font-sans">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="relative">
          <label htmlFor="ncd-search" className="sr-only">
            Search NCD data
          </label>
          <svg
            className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.3-4.3" />
          </svg>
          <input
            id="ncd-search"
            type="search"
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            placeholder="Search by name, sub center, Aadhaar, or disease"
            className="w-full rounded-xl border border-gray-200 bg-white py-3 pl-12 pr-4 text-sm text-gray-900 shadow-sm outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
          />
        </div>

        {/* NCD Data Card Header */}
        <div className="bg-orange-500 rounded-2xl p-4 flex items-center justify-between shadow-lg text-white">
          <h2 className="text-xl font-semibold">NCD Data</h2>
          <button className="flex items-center space-x-2 bg-orange-400 hover:bg-orange-600 transition-colors duration-200 text-white font-medium py-2 px-4 rounded-full shadow">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M5 12h14" />
              <path d="M12 5v14" />
            </svg>
            <span>Add</span>
          </button>
        </div>

        {/* NCD Data Table */}
        <div className="bg-white rounded-2xl p-6 shadow-lg overflow-x-auto">
          <div className="w-full">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-orange-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider rounded-tl-xl"
                  >
                    S.NO
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                  >
                    Sub Center Name
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                  >
                    Name
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                  >
                    Adhar No
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                  >
                    Disease
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider rounded-tr-xl"
                  >
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredData.map((item, index) => (
                  <tr
                    key={item.id}
                    className="hover:bg-gray-50 transition-colors duration-150"
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {index + 1}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                      {item.subCenter}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {item.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.adharNo}
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900 space-y-1">
                        {item.diseases.length > 0 ? (
                          item.diseases.map((disease, i) => (
                            <span
                              key={i}
                              className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 mr-2"
                            >
                              {disease}
                            </span>
                          ))
                        ) : (
                          <span className="text-gray-400">N/A</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex items-center space-x-2">
                        {item.prescribed ? (
                          <span className="text-green-600 font-bold">
                            Prescribed
                          </span>
                        ) : (
                          <button
                            className="text-orange-500 hover:text-orange-700"
                            title="Prescribe Medication"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M12 20h9" />
                              <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z" />
                            </svg>
                          </button>
                        )}
                        <button
                          className="text-gray-400 hover:text-red-500"
                          title="Delete"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="20"
                            height="20"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M3 6h18" />
                            <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                            <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredData.length === 0 && (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-6 py-8 text-center text-sm text-gray-500"
                    >
                      No NCD records match your search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NCDData;
