"use client";
import { useState, useEffect } from "react";
import {
  Plus,
  Package,
  Edit,
  Trash2,
  Save,
  X,
  AlertTriangle,
} from "lucide-react";
import { useTranslations } from "next-intl";
import Axios from "@/lib/api";

interface SupplyItem {
  id: string;
  name: string;
  quantity: number;
  unit: "PIECES" | "KG" | "LITRES" | "PACKETS" | "BOTTLES" | "OTHER";
  threshold: number;  // minimum quantity to show low stock warning
}

type SupplyForm = Omit<SupplyItem, "id" | "unit"> & {
  unit: SupplyItem["unit"] | "";
};

const SuppliesPage = () => {
  const t = useTranslations('supplies');
  const tCommon = useTranslations('common');
  const [supplies, setSupplies] = useState<SupplyItem[]>([]);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [newSupply, setNewSupply] = useState<SupplyForm>({
    name: "",
    quantity: 0,
    unit: "",
    threshold: 10,
  });

  useEffect(() => {
    const loadSupplies = async () => {
      try {
        const response = await Axios.get<SupplyItem[]>("/supplies");
        setSupplies(response.data);
        setError(null);
      } catch {
        setError("Unable to load supplies. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    void loadSupplies();
  }, []);

  const handleSave = async () => {
    if (!newSupply.name.trim() || newSupply.quantity < 0 || !newSupply.unit) {
      setError("Please enter a valid supply name, quantity, and unit.");
      return;
    }

    try {
      const supplyInput: Omit<SupplyItem, "id"> = {
        ...newSupply,
        unit: newSupply.unit,
      };
      const response = editingId
        ? await Axios.put<SupplyItem>(`/supplies?id=${encodeURIComponent(editingId)}`, supplyInput)
        : await Axios.post<SupplyItem>("/supplies", supplyInput);
      setSupplies((current) =>
        editingId
          ? current.map((item) => (item.id === editingId ? response.data : item))
          : [response.data, ...current],
      );
      setNewSupply({
        name: "",
        quantity: 0,
        unit: "",
        threshold: 10,
      });
      setIsAddingNew(false);
      setEditingId(null);
      setError(null);
    } catch {
      setError("Unable to save supply. Please try again.");
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm(t('deleteConfirm'))) {
      try {
        await Axios.delete(`/supplies?id=${encodeURIComponent(id)}`);
        setSupplies((current) => current.filter((supply) => supply.id !== id));
        setError(null);
      } catch {
        setError("Unable to delete supply. Please try again.");
      }
    }
  };

  const startEditing = (supply: SupplyItem) => {
    setEditingId(supply.id);
    setNewSupply({
      name: supply.name,
      quantity: supply.quantity,
      unit: supply.unit,
      threshold: supply.threshold,
    });
    setIsAddingNew(true);
  };

  const handleInputChange = (
    field: keyof Omit<SupplyItem, "id">,
    value: string | number
  ) => {
    setNewSupply((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100">
      <div className="px-3 py-4 max-w-4xl mx-auto">
        {/* Header with Add Button */}
        {/* Quick Stats */}
        <div className="mb-8 bg-white rounded-xl shadow-lg border border-orange-100 p-8">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">{t('supplyOverview')}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">578</div>
              <div className="text-gray-600">{t('totalItemsAvailable')}</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">89%</div>
              <div className="text-gray-600">{t('stockAvailability')}</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">145</div>
              <div className="text-gray-600">{t('centersServed')}</div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-lg border border-orange-100 mb-4">
          <div className="px-4 py-3 bg-gradient-to-r from-orange-500 to-orange-600 rounded-t-xl">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold text-white">{t('supplyInventory')}</h3>
              <button
                onClick={() => {
                  setEditingId(null);
                  setIsAddingNew(true);
                }}
                className="bg-white text-orange-600 px-3 py-2 rounded-lg font-medium text-sm hover:bg-orange-50 transition duration-200 flex items-center space-x-1"
              >
                <Plus className="h-4 w-4" />
                <span>{t('addSupply')}</span>
              </button>
            </div>
          </div>

          {/* Add New Supply Form */}
          {isAddingNew && (
            <div className="p-4 bg-orange-25 border-b border-orange-100">
              <h4 className="font-semibold text-gray-900 mb-3">
                {editingId ? "Edit Supply" : t('addNewSupply')}
              </h4>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    {t('supplyName')}
                  </label>
                  <input
                    type="text"
                    value={newSupply.name}
                    onChange={(e) =>
                      handleInputChange("name", e.target.value)
                    }
                    placeholder={t('supplyNamePlaceholder')}
                    className="w-full px-3 py-2 border border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      {t('quantity')}
                    </label>
                    <input
                      type="number"
                      value={newSupply.quantity}
                      onChange={(e) =>
                        handleInputChange("quantity", parseInt(e.target.value) || 0)
                      }
                      min="0"
                      placeholder={t('quantityPlaceholder')}
                      className="w-full px-3 py-2 border border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      {t('unit')}
                    </label>
                    <select
                      value={newSupply.unit}
                      onChange={(e) =>
                        handleInputChange("unit", e.target.value as SupplyItem["unit"])
                      }
                      className="w-full px-3 py-2 border border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                    >
                      <option value="">Select unit</option>
                      <option value="PIECES">Pieces</option>
                      <option value="KG">Kg</option>
                      <option value="LITRES">Litres</option>
                      <option value="PACKETS">Packets</option>
                      <option value="BOTTLES">Bottles</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    {t('lowStockThreshold')}
                  </label>
                  <input
                    type="number"
                    value={newSupply.threshold}
                    onChange={(e) =>
                      handleInputChange("threshold", parseInt(e.target.value) || 0)
                    }
                    min="0"
                    placeholder={t('lowStockThresholdPlaceholder')}
                    className="w-full px-3 py-2 border border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                  />
                </div>

                <div className="flex space-x-3 pt-2">
                  <button
                    onClick={() => void handleSave()}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg font-medium text-sm transition duration-200 flex items-center justify-center space-x-1"
                  >
                    <Save className="h-4 w-4" />
                    <span>{t('saveSupply')}</span>
                  </button>
                  <button
                    onClick={() => {
                      setIsAddingNew(false);
                      setEditingId(null);
                    }}
                    className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded-lg font-medium text-sm transition duration-200 flex items-center justify-center space-x-1"
                  >
                    <X className="h-4 w-4" />
                    <span>{tCommon('cancel')}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Supplies List */}
          <div className="divide-y divide-orange-100">
            {error && <div className="p-4 text-sm text-red-700 bg-red-50">{error}</div>}
            {isLoading ? (
              <div className="p-8 text-center text-gray-500">Loading supplies...</div>
            ) : supplies.map((supply) => (
              <div
                key={supply.id}
                className="p-4 flex items-center justify-between hover:bg-orange-50"
              >
                <div className="flex items-start space-x-3">
                  <div className="h-10 w-10 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Package className="h-5 w-5 text-orange-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-900 capitalize">
                      {supply.name}
                    </h4>
                    <p className="text-sm text-gray-600 lowercase">
                      {supply.quantity} {supply.unit}
                    </p>
                    {supply.quantity <= supply.threshold && (
                      <div className="flex items-center space-x-1 text-xs text-amber-600 mt-1">
                        <AlertTriangle className="h-3 w-3" />
                        <span>{t('lowStock')}</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => startEditing(supply)}
                    className="text-orange-600 hover:text-orange-800 p-1"
                    aria-label="Edit supply"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(supply.id)}
                    className="text-red-600 hover:text-red-800 p-1"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
            {!isLoading && supplies.length === 0 && (
              <div className="p-8 text-center text-gray-500">
                <Package className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <p>{t('noSuppliesYet')}</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer Stats */}
        <div className="mt-4 bg-white rounded-xl shadow-lg border border-orange-100 p-4">
          <div className="flex justify-between items-center text-sm text-gray-600">
            <span>{t('totalItems', { count: supplies.length })}</span>
            <span className="text-xs">
              {t('lastUpdated')}: {new Date().toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuppliesPage;
