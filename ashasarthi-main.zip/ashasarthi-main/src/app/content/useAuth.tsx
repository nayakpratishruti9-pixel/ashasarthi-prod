"use client";

import { SessionProvider, useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { ReactNode, useEffect } from "react";
import { signOut } from "next-auth/react";

interface ClientProviderProps {
  children: ReactNode;
}


//this function is still not completed yet 
export const ProtectedRoute = ({ children }: { children: ReactNode }) => {
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (status === "loading") return; 
    if (!session) {
      router.push("/signin"); // Redirect to login if not authenticated
    }
  }, [session, status, router]);

  if (status === "loading") {
    return null;
  }

  return <>{children}</>;
};

export  const handleSignOut = async () => {
    await signOut({ callbackUrl: '/signin' });
  }


export function ClientProvider({ children }: ClientProviderProps) {
  return (
    <SessionProvider>
      <ProtectedRoute>{children}</ProtectedRoute>
    </SessionProvider>
  );
}

