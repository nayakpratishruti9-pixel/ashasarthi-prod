import Groq from "groq-sdk";
import { NextRequest, NextResponse } from "next/server";

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message, locale = "en" } = body;

    // Language mapping for AI responses
    const languageNames: Record<string, string> = {
      en: "English",
      hi: "Hindi",
      or: "Odia",
      ta: "Tamil",
      te: "Telugu",
      ml: "Malayalam",
      es: "Spanish",
    };

    const languageName = languageNames[locale] || "English";

    const chatCompletion = await groq.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are an AI support assistant for AshaSarthi, a healthcare management system for ASHA workers in Odisha, India.

Your role:
- Provide quick, concise help about the app's features (20-30 words max)
- Guide users on: Dashboard (patient/supply records), Supplies (medicine inventory tracking), NCD Data (non-communicable disease patient tracking), Vaccination records, Contact, and Settings
- Answer questions about managing patient data, tracking supplies/inventory, recording vaccination and health info
- Assist with offline functionality and data syncing features
- Help troubleshoot basic app usage issues
- ONLY discuss AshaSarthi app features - politely decline unrelated requests

IMPORTANT: Respond ONLY in ${languageName}. Keep responses SHORT (under 100 words), friendly, and action-oriented. Use simple language suitable for healthcare workers.`,
        },
        {
          role: "user",
          content: message || "How can I use this app?",
        },
      ],
      model: "llama-3.3-70b-versatile",
      temperature: 0.7,
      max_tokens: 200,
    });

    return NextResponse.json({
      message: chatCompletion.choices[0]?.message?.content || "",
    });
  } catch (error) {
    console.error("Error in AI chat:", error);
    return NextResponse.json(
      { error: "Failed to process chat request" },
      { status: 500 }
    );
  }
}
