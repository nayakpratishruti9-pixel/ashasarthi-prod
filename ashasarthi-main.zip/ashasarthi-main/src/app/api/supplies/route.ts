import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { getSequelize, Supplies } from "../../../../backend/database/connection";

const allowedUnits = [
  "PIECES",
  "KG",
  "LITRES",
  "PACKETS",
  "BOTTLES",
  "OTHER",
] as const;
type SupplyUnit = (typeof allowedUnits)[number];

type SupplyInput = {
  name: string;
  unit: SupplyUnit;
  quantity: number;
  threshold: number;
};

async function readSupplyInput(request: NextRequest) {
  try {
    return parseInput(await request.json());
  } catch {
    return null;
  }
}

function isUuid(value: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
    value,
  );
}

function parseInput(body: unknown): SupplyInput | null {
  if (!body || typeof body !== "object" || Array.isArray(body)) return null;
  const value = body as Record<string, unknown>;
  const name = typeof value.name === "string" ? value.name.trim() : "";
  const unit = typeof value.unit === "string" ? value.unit : "";
  const quantity = value.quantity;
  const threshold = value.threshold;

  if (
    name.length < 1 ||
    name.length > 100 ||
    !allowedUnits.includes(unit as SupplyUnit) ||
    typeof quantity !== "number" ||
    !Number.isFinite(quantity) ||
    quantity < 0 ||
    quantity > 99999999 ||
    typeof threshold !== "number" ||
    !Number.isFinite(threshold) ||
    threshold < 0 ||
    threshold > 99999999
  ) {
    return null;
  }

  return { name, unit: unit as SupplyUnit, quantity, threshold };
}

async function getUserId(request: NextRequest) {
  const token = await getToken({
    req: request,
    secret: process.env.NEXTAUTH_SECRET,
  });
  return token?.sub && isUuid(token.sub) ? token.sub : null;
}

function serializeSupply(supply: Supplies) {
  return {
    id: supply.id,
    name: supply.item_name,
    unit: supply.unit,
    quantity: Number(supply.available_quantity),
    threshold: Number(supply.low_stock_threshold),
  };
}

export async function GET(request: NextRequest) {
  try {
    getSequelize();
    const creatorId = await getUserId(request);
    if (!creatorId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const supplies = await Supplies.findAll({
      where: { creator_id: creatorId },
      order: [["createdAt", "DESC"]],
    });
    return NextResponse.json(supplies.map(serializeSupply));
  } catch (error) {
    console.error("Error loading supplies:", error);
    return NextResponse.json({ error: "Unable to load supplies" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    getSequelize();
    const creatorId = await getUserId(request);
    if (!creatorId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const input = await readSupplyInput(request);
    if (!input) {
      return NextResponse.json({ error: "Invalid supply data" }, { status: 400 });
    }

    const supply = await Supplies.create({
      creator_id: creatorId,
      item_name: input.name,
      unit: input.unit,
      available_quantity: input.quantity,
      low_stock_threshold: input.threshold,
    });
    return NextResponse.json(serializeSupply(supply), { status: 201 });
  } catch (error) {
    console.error("Error creating supply:", error);
    return NextResponse.json({ error: "Unable to create supply" }, { status: 500 });
  }
}

async function getOwnedSupply(request: NextRequest, creatorId: string) {
  const id = request.nextUrl.searchParams.get("id");
  if (!id || !isUuid(id)) return null;
  return Supplies.findOne({ where: { id, creator_id: creatorId } });
}

export async function PUT(request: NextRequest) {
  try {
    const creatorId = await getUserId(request);
    if (!creatorId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const supply = await getOwnedSupply(request, creatorId);
    if (!supply) return NextResponse.json({ error: "Supply not found" }, { status: 404 });

    const input = await readSupplyInput(request);
    if (!input) return NextResponse.json({ error: "Invalid supply data" }, { status: 400 });

    await supply.update({
      item_name: input.name,
      unit: input.unit,
      available_quantity: input.quantity,
      low_stock_threshold: input.threshold,
    });
    return NextResponse.json(serializeSupply(supply));
  } catch (error) {
    console.error("Error updating supply:", error);
    return NextResponse.json({ error: "Unable to update supply" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const creatorId = await getUserId(request);
    if (!creatorId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const supply = await getOwnedSupply(request, creatorId);
    if (!supply) return NextResponse.json({ error: "Supply not found" }, { status: 404 });

    await supply.destroy();
    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error("Error deleting supply:", error);
    return NextResponse.json({ error: "Unable to delete supply" }, { status: 500 });
  }
}