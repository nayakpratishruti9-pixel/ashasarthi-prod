import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import {
  Distributions,
  getSequelize,
  Supplies,
} from "../../../../backend/database/connection";

const allowedUnits = [
  "PIECES",
  "KG",
  "LITRES",
  "PACKETS",
  "BOTTLES",
  "DOSES",
  "OTHER",
] as const;

function isUuid(value: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

async function getUserId(request: NextRequest) {
  const token = await getToken({
    req: request,
    secret: process.env.NEXTAUTH_SECRET,
  });
  return token?.sub && isUuid(token.sub) ? token.sub : null;
}

function serializeDistribution(distribution: Distributions) {
  return {
    id: distribution.id,
    date: distribution.distributed_at.toISOString(),
    suppliesName: distribution.supply_name,
    quantity: Number(distribution.quantity),
    unit: distribution.unit,
    recipientName: distribution.beneficiary_name ?? "",
    wardNo: distribution.ward_no ?? "",
  };
}

export async function GET(request: NextRequest) {
  try {
    getSequelize();
    const creatorId = await getUserId(request);
    if (!creatorId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const distributions = await Distributions.findAll({
      order: [["distributed_at", "DESC"]],
    });
    return NextResponse.json(distributions.map(serializeDistribution));
  } catch (error) {
    console.error("Error loading distributions:", error);
    return NextResponse.json({ error: "Unable to load distributions" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    getSequelize();
    const creatorId = await getUserId(request);
    if (!creatorId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const supplyId = typeof body.supplyId === "string" ? body.supplyId : "";
    const quantity = body.quantity;
    const beneficiaryName = typeof body.recipientName === "string" ? body.recipientName.trim() : "";
    const wardNo = typeof body.wardNo === "string" ? body.wardNo.trim() : "";
    const unit = typeof body.unit === "string" ? body.unit : "";

    if (
      !isUuid(supplyId) ||
      !Number.isFinite(quantity) ||
      quantity <= 0 ||
      typeof unit !== "string" ||
      !allowedUnits.includes(unit as (typeof allowedUnits)[number]) ||
      !beneficiaryName ||
      !wardNo
    ) {
      return NextResponse.json({ error: "Invalid distribution data" }, { status: 400 });
    }

    const supply = await Supplies.findOne({ where: { id: supplyId, creator_id: creatorId } });
    if (!supply) {
      return NextResponse.json({ error: "Supply not found" }, { status: 404 });
    }

    const availableQuantity = Number(supply.available_quantity);
    if (availableQuantity < quantity) {
      return NextResponse.json({ error: "Not enough supply in stock" }, { status: 409 });
    }

    const distribution = await Distributions.create({
      supply_name: supply.item_name,
      beneficiary_name: beneficiaryName,
      ward_no: wardNo,
      quantity,
      unit,
      distributed_at: new Date(),
    });

    return NextResponse.json(
      serializeDistribution(distribution),
      { status: 201 },
    );
  } catch (error) {
    console.error("Error creating distribution:", error);
    return NextResponse.json({ error: "Unable to create distribution" }, { status: 500 });
  }
}
