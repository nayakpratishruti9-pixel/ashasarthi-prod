import { NextRequest, NextResponse } from "next/server";
import { getSequelize, User } from "../../../../backend/database/connection";
import bcrypt from "bcryptjs";

const allowedRoles = ["asha", "awcs"] as const;
type SignupRole = (typeof allowedRoles)[number];

export async function POST(req: NextRequest) {
  try {
    getSequelize();
    const body = await req.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return NextResponse.json(
        { error: "Invalid request body" },
        { status: 400 },
      );
    }

    const name = typeof body.name === "string" ? body.name.trim() : "";
    const phone = typeof body.phone === "string" ? body.phone.trim() : "";
    const email =
      typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body.password === "string" ? body.password : "";
    const role = body.role as SignupRole;

    if (!name || !phone || !email || !password || !allowedRoles.includes(role)) {
      return NextResponse.json(
        { error: "Name, contact number, email, password, and a valid role are required" },
        { status: 400 },
      );
    }

    if (name.length < 2 || name.length > 100) {
      return NextResponse.json(
        { error: "Name must be between 2 and 100 characters" },
        { status: 400 },
      );
    }

    const phoneDigits = phone.replace(/\D/g, "");
    if (
      !/^\+?[0-9\s()-]+$/.test(phone) ||
      phoneDigits.length < 10 ||
      phoneDigits.length > 15
    ) {
      return NextResponse.json(
        { error: "Please enter a valid contact number" },
        { status: 400 },
      );
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json(
        { error: "Please enter a valid email address" },
        { status: 400 },
      );
    }

    if (
      password.length < 8 ||
      !/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(password)
    ) {
      return NextResponse.json(
        {
          error:
            "Password must be at least 8 characters and contain an uppercase letter, lowercase letter, and number",
        },
        { status: 400 },
      );
    }

    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return NextResponse.json(
        { error: "User already exists" },
        { status: 409 },
      );
    }

    await User.create({
      name,
      phone,
      email,
      role,
      password_hash: await bcrypt.hash(password, 10),
    });

    return NextResponse.json(
      { message: "Account created successfully" },
      { status: 201 },
    );
  } catch (error) {
    console.error("Error creating user:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 },
    );
  }
}