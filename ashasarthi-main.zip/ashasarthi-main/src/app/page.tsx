"use client";

import {
  Bell,
  ClipboardClock,
  HeartPulse,
  MapPin,
  Package,
  ShieldCheck,
  Users,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { initDB, seedSampleData } from "@/lib/db";
import Chatbot from "@/components/Chatbot";
import Axios from "@/lib/api";

interface SupplyItem {
  id: string;
  name: string;
  quantity: number;
  unit: "PIECES" | "KG" | "LITRES" | "PACKETS" | "BOTTLES" | "OTHER";
  threshold: number;
}

interface CentreMember {
  id: string;
  name: string;
  designation: "anm" | "ashaWorker";
  ward: string;
  status: "active" | "onLeave";
}

const centreMembers: CentreMember[] = [
  {
    id: "member-1",
    name: "Debanjana Nayak",
    designation: "anm",
    ward: "598",
    status: "active",
  },
  {
    id: "member-2",
    name: "Sunita Naik",
    designation: "ashaWorker",
    ward: "598",
    status: "active",
  },
  {
    id: "member-3",
    name: "Mamita Majhi",
    designation: "ashaWorker",
    ward: "598",
    status: "active",
  },
  {
    id: "member-4",
    name: "Sangita Bhoi",
    designation: "ashaWorker",
    ward: "598",
    status: "onLeave",
  },
];

const HomePage = () => {
  const t = useTranslations("home");
  const [dbReady, setDbReady] = useState(false);
  const [supplies, setSupplies] = useState<SupplyItem[]>([]);

  useEffect(() => {
    const initializeApp = async () => {
      try {
        await initDB();
        await seedSampleData();
        setDbReady(true);
      } catch (error) {
        console.error("Failed to initialize database:", error);
      }
    };

    initializeApp();
  }, []);

  useEffect(() => {
    const loadSupplies = async () => {
      try {
        const response = await Axios.get<SupplyItem[]>("/supplies");
        setSupplies(response.data);
      } catch (error) {
        console.error("Failed to load supplies for home page:", error);
      }
    };

    void loadSupplies();
  }, []);

  return (
    <div className="min-h-[calc(100vh-64px)] bg-[#fffaf5] text-gray-900">
      {!dbReady && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/90">
          <div className="text-center">
            <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-4 border-orange-100 border-t-orange-500" />
            <p className="text-sm text-gray-600">{t("initializingStorage")}</p>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-7xl space-y-8 px-4 py-6 sm:px-6 lg:px-8 lg:py-10">
        <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-orange-600 via-orange-500 to-amber-400  text-white shadow-xl ">
          <div className="absolute -right-20 -top-24 h-72 w-72 rounded-full bg-white/10" />
          <div className="absolute -bottom-32 right-20 h-64 w-64 rounded-full bg-orange-800/10" />

          <div className="relative grid gap-10 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">


            <div className="rounded-2xl  p-5 backdrop-blur-sm sm:p-6">
              <div className="mb-4 flex items-start gap-3">
                <div className="rounded-xl bg-white p-2.5 text-orange-600">
                  <MapPin className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-orange-100">
                    {t("centreAddress")}
                  </p>
                  <h2 className="mt-1 text-xl font-bold">{t("centreName")}</h2>
                </div>
              </div>
              <address className="not-italic text-sm leading-6 text-orange-50">
                {t("addressLine")}
                <br />
                {t("wardAddress")}
              </address>
              
            </div>
            <div className=" grid grid-row-2 gap-3 pl-8 pb-5 border-white/20 pt-4">
                <div>
                  <p className="text-xs text-orange-100">{t("anm")}</p>
                  <p className="mt-1 font-semibold">Debanjana Nayak</p>
                </div>
                <div>
                  <p className="text-xs text-orange-100">{t("totalStaff")}</p>
                  <p className="mt-1 font-semibold">{t("memberCount", { count: centreMembers.length })}</p>
                </div>
              </div>
          </div>
        </section>

        <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { label: t("centreStaff"), value: centreMembers.length.toString(), icon: Users },
            { label: t("activeProgrammes"), value: "04", icon: ShieldCheck },
            { label: t("recordsThisMonth"), value: "128", icon: ClipboardClock },
            {
              label: t("suppliesTracked"),
              value: supplies.reduce((total, supply) => total + supply.quantity, 0).toString(),
              icon: Package,
            },
          ].map((stat) => {
            const Icon = stat.icon;
            return (
              <div
                key={stat.label}
                className="rounded-2xl border border-orange-100 bg-white p-4 shadow-sm sm:p-5"
              >
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium text-gray-500 sm:text-sm">
                    {stat.label}
                  </p>
                  <Icon className="h-4 w-4 text-orange-500" />
                </div>
                <p className="mt-3 text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
            );
          })}
        </section>

        <section className="grid overflow-hidden rounded-2xl border border-orange-100 bg-white shadow-sm lg:grid-cols-[minmax(0,1fr)_20rem]">
          <div className="min-w-0 lg:border-r lg:border-orange-100">
            <div className="flex flex-col gap-2 border-b border-orange-100 px-5 py-5 sm:flex-row sm:items-end sm:justify-between sm:px-6">
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.16em] text-orange-600">
                  {t("centreMembers")}
                </p>
              </div>
              <p className="text-sm text-gray-500">
                {t("staffCoverage")}
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-orange-50">
                  <tr>
                    {[t("sno"), t("name"), t("designation"), t("ward"), t("status")].map(
                      (heading) => (
                        <th
                          key={heading}
                          scope="col"
                          className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-700 sm:px-6"
                        >
                          {heading}
                        </th>
                      ),
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {centreMembers.map((member, index) => (
                    <tr key={member.id} className="transition hover:bg-orange-50/50">
                      <td className="whitespace-nowrap px-5 py-4 text-sm text-gray-500 sm:px-6">
                        {String(index + 1).padStart(2, "0")}
                      </td>
                      <td className="whitespace-nowrap px-5 py-4 text-sm font-semibold text-gray-900 sm:px-6">
                        {member.name}
                      </td>
                      <td className="whitespace-nowrap px-5 py-4 text-sm text-gray-600 sm:px-6">
                        {t(member.designation)}
                      </td>
                      <td className="whitespace-nowrap px-5 py-4 text-sm text-gray-600 sm:px-6">
                        {member.ward}
                      </td>
                      <td className="whitespace-nowrap px-5 py-4 sm:px-6">
                        <span
                          className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${
                            member.status === "active"
                              ? "bg-emerald-100 text-emerald-700"
                              : "bg-amber-100 text-amber-700"
                          }`}
                        >
                          {t(member.status)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <aside className="bg-orange-50/50 p-5 sm:p-6" aria-labelledby="notifications-heading">
            <div className="mb-5 flex items-center gap-3">
              <div className="rounded-xl bg-orange-100 p-2.5 text-orange-600">
                <Bell className="h-5 w-5" aria-hidden="true" />
              </div>
              <div>
                {/* <p className="text-xs font-semibold uppercase tracking-wider text-orange-600">
                  Updates
                </p> */}
                <h2 id="notifications-heading" className="text-lg font-bold text-orange-600">
                  {t("updatesTitle")}
                </h2>
              </div>
            </div>

            <div className="space-y-3">
              <div className="rounded-xl border border-orange-100 bg-white p-3 shadow-sm">
                <p className="text-sm font-semibold text-gray-900">
                  {t("staffMeetingTitle")}
                </p>
                <p className="mt-1 text-xs leading-5 text-gray-500">
                  {t("staffMeetingDescription")}
                </p>
                <p className="mt-2 text-xs font-medium text-orange-600">
                  {t("staffMeetingDate")}
                </p>
              </div>
              <div className="rounded-xl border border-amber-100 bg-white p-3 shadow-sm">
                <p className="text-sm font-semibold text-gray-900">
                  {t("supplyReviewTitle")}
                </p>
                <p className="mt-1 text-xs leading-5 text-gray-500">
                  {t("supplyReviewDescription")}
                </p>
                <p className="mt-2 text-xs font-medium text-orange-600">
                  {t("actionRequired")}
                </p>
              </div>
              <div className="rounded-xl border border-emerald-100 bg-white p-3 shadow-sm">
                <p className="text-sm font-semibold text-gray-900">
                  {t("recordsTitle")}
                </p>
                <p className="mt-1 text-xs leading-5 text-gray-500">
                  {t("recordsDescription")}
                </p>
                <p className="mt-2 text-xs font-medium text-emerald-600">
                  {t("completed")}
                </p>
              </div>
            </div>
          </aside>
        </section>
      </main>

      <Chatbot />
    </div>
  );
};

export default HomePage;
