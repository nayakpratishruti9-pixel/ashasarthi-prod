/**
 * Custom React hooks for offline functionality
 * These hooks enable network awareness and offline data management
 */

'use client';

import { useState, useEffect } from 'react';

/**
 * Hook to detect online/offline status
 * Returns true when online, false when offline
 */
export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    // Check initial status
    setIsOnline(navigator.onLine);

    // Listen for network changes
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}

/**
 * Hook to manage offline data with IndexedDB
 * Provides methods to load and save data while handling offline scenarios
 */
export function useOfflineData<T>(
  storeName: 'dashboard' | 'settings' | 'drafts',
  fetchOnline?: () => Promise<T[]>
) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const isOnline = useOnlineStatus();

  useEffect(() => {
    loadData();
  }, [isOnline]);

  const loadData = async () => {
    setLoading(true);
    setError(null);

    try {
      // If online and fetch function provided, try to fetch fresh data
      if (isOnline && fetchOnline) {
        try {
          const freshData = await fetchOnline();
          setData(freshData);
          // Store in IndexedDB for offline use
          // This would be implemented in the component
        } catch (err) {
          console.error('Error fetching online data:', err);
          // Fall back to offline data
          await loadOfflineData();
        }
      } else {
        // Load from IndexedDB when offline
        await loadOfflineData();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const loadOfflineData = async () => {
    // Dynamic import to avoid SSR issues
    const { initDB } = await import('@/lib/db');
    const db = await initDB();
    const offlineData = await db.getAll(storeName as any);
    setData(offlineData as any);
  };

  const refresh = () => {
    loadData();
  };

  return { data, loading, error, isOnline, refresh };
}

/**
 * Hook to detect if app is installed as PWA
 */
export function useIsPWA() {
  const [isPWA, setIsPWA] = useState(false);

  useEffect(() => {
    // Check if app is running in standalone mode (installed PWA)
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    setIsPWA(isStandalone || (navigator as any).standalone === true);
  }, []);

  return isPWA;
}

/**
 * Hook to handle PWA installation prompt
 */
export function useInstallPrompt() {
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const promptInstall = async () => {
    if (!installPrompt) return false;

    installPrompt.prompt();
    const result = await installPrompt.userChoice;

    if (result.outcome === 'accepted') {
      setIsInstallable(false);
      setInstallPrompt(null);
      return true;
    }

    return false;
  };

  return { isInstallable, promptInstall };
}
