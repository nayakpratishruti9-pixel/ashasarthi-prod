/**
 * IndexedDB utilities for offline data storage
 * This enables the app to store and retrieve data locally when offline
 */

import { openDB, DBSchema, IDBPDatabase } from "idb";

// Define the database schema
interface AppDB extends DBSchema {
  dashboard: {
    key: string;
    value: {
      id: string;
      title: string;
      description: string;
      status: string;
      createdAt: string;
      updatedAt: string;
    };
  };
  settings: {
    key: string;
    value: {
      key: string;
      value: any;
      updatedAt: string;
    };
  };
  drafts: {
    key: string;
    value: {
      id: string;
      formType: string;
      data: any;
      createdAt: string;
      updatedAt: string;
    };
  };
}

let dbInstance: IDBPDatabase<AppDB> | null = null;

/**
 * Initialize and open the IndexedDB database
 * Creates object stores if they don't exist
 */
export async function initDB(): Promise<IDBPDatabase<AppDB>> {
  if (dbInstance) {
    return dbInstance;
  }

  dbInstance = await openDB<AppDB>("ashasarthi-offline-db",1, {
    upgrade(db) {
      // Create dashboard store
      if (!db.objectStoreNames.contains("dashboard")) {
        db.createObjectStore("dashboard", { keyPath: "id" });
      }

      // Create settings store
      if (!db.objectStoreNames.contains("settings")) {
        db.createObjectStore("settings", { keyPath: "key" });
      }

      // Create drafts store for offline form submissions
      if (!db.objectStoreNames.contains("drafts")) {
        db.createObjectStore("drafts", { keyPath: "id" });
      }
    },
  });

  return dbInstance;
}

/**
 * Dashboard data operations
 */
export async function getDashboardData() {
  const db = await initDB();
  return await db.getAll("dashboard");
}

export async function saveDashboardItem(item: AppDB["dashboard"]["value"]) {
  const db = await initDB();
  await db.put("dashboard", item);
}

export async function deleteDashboardItem(id: string) {
  const db = await initDB();
  await db.delete("dashboard", id);
}

/**
 * Settings operations
 */
export async function getSetting(key: string) {
  const db = await initDB();
  return await db.get("settings", key);
}

export async function saveSetting(key: string, value: any) {
  const db = await initDB();
  await db.put("settings", {
    key,
    value,
    updatedAt: new Date().toISOString(),
  });
}

export async function getAllSettings() {
  const db = await initDB();
  return await db.getAll("settings");
}

/**
 * Draft operations for offline form submissions
 */
export async function saveDraft(draft: AppDB["drafts"]["value"]) {
  const db = await initDB();
  await db.put("drafts", draft);
}

export async function getDrafts() {
  const db = await initDB();
  return await db.getAll("drafts");
}

export async function deleteDraft(id: string) {
  const db = await initDB();
  await db.delete("drafts", id);
}

/**
 * Seed sample data for testing offline functionality
 */
export async function seedSampleData() {
  const db = await initDB();

  // Check if data already exists
  const existingData = await db.getAll("dashboard");
  if (existingData.length > 0) {
    return; // Data already seeded
  }

  // Seed dashboard items
  const sampleDashboardItems = [
    {
      id: "1",
      title: "Health Survey Complete",
      description: "Monthly community health survey data collected",
      status: "completed",
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "2",
      title: "Vaccination Drive",
      description: "Community vaccination campaign scheduled",
      status: "pending",
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "3",
      title: "Nutrition Program",
      description: "Child nutrition monitoring in progress",
      status: "in-progress",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ];

  for (const item of sampleDashboardItems) {
    await db.put("dashboard", item);
  }

  // Seed default settings
  await saveSetting("theme", "light");
  await saveSetting("notifications", true);
  await saveSetting("language", "en");
}

/**
 * Clear all data from the database
 */
export async function clearAllData() {
  const db = await initDB();
  await db.clear("dashboard");
  await db.clear("settings");
  await db.clear("drafts");
}
