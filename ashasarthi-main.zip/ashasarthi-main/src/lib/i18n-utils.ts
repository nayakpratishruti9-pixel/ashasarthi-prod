/**
 * Utility functions for i18n
 */

import { Locale, locales, defaultLocale } from "@/../i18n";

/**
 * Get locale display name in its native language
 */
export function getLocaleDisplayName(locale: Locale): string {
  const names: Record<Locale, string> = {
    en: "English",
    hi: "हिन्दी",
    or: "ଓଡ଼ିଆ",
    es: "Español",
    ta: "தமிழ்",
    te: "తెలుగు",
    ml: "മലയാളം",
  };
  return names[locale] || locale;
}

/**
 * Get locale from cookie
 */
export function getLocaleFromCookie(): Locale | null {
  if (typeof document === "undefined") return null;

  const cookie = document.cookie
    .split("; ")
    .find((row) => row.startsWith("NEXT_LOCALE="));

  if (!cookie) return null;

  const locale = cookie.split("=")[1] as Locale;
  return locales.includes(locale) ? locale : null;
}

/**
 * Set locale in cookie
 */
export function setLocaleCookie(locale: Locale): void {
  if (typeof document === "undefined") return;

  document.cookie = `NEXT_LOCALE=${locale}; path=/; max-age=31536000; SameSite=Lax`;
}

/**
 * Validate if a string is a valid locale
 */
export function isValidLocale(locale: string): locale is Locale {
  return locales.includes(locale as Locale);
}

/**
 * Get locale with fallback to default
 */
export function getLocaleWithFallback(locale?: string | null): Locale {
  if (!locale || !isValidLocale(locale)) {
    return defaultLocale;
  }
  return locale;
}

/**
 * Get all available locales
 */
export function getAvailableLocales() {
  return locales.map((locale) => ({
    code: locale,
    name: getLocaleDisplayName(locale),
  }));
}
