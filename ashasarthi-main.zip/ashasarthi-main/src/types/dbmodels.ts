
interface UserModel {
    id: string;
    fullname: string;
    email: string;
    role: string;
    phone: string;
    password_hash: string;

}

interface RecordsModel {
    id: string;
    supply: string;
    recipient_name: string;
    ward_no: string;
    vaccination: string;
    age: string;
}
export type { RecordsModel, UserModel };