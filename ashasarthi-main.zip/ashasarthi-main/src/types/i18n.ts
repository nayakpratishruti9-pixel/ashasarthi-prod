import { Locale } from '@/../i18n';

declare global {
  // Use type safe message keys with `next-intl`
  interface IntlMessages {
    common: {
      save: string;
      cancel: string;
      delete: string;
      edit: string;
      loading: string;
      submit: string;
      search: string;
      filter: string;
      export: string;
      import: string;
      close: string;
      confirm: string;
      back: string;
      next: string;
      previous: string;
      yes: string;
      no: string;
    };
    navigation: {
      home: string;
      dashboard: string;
      supplies: string;
      contact: string;
      help: string;
      preview: string;
      ncdData: string;
      signOut: string;
      profile: string;
    };
    auth: {
      signIn: string;
      signUp: string;
      signOut: string;
      email: string;
      password: string;
      confirmPassword: string;
      forgotPassword: string;
      rememberMe: string;
      noAccount: string;
      hasAccount: string;
      createAccount: string;
      loginSuccess: string;
      logoutSuccess: string;
      invalidCredentials: string;
      fullName: string;
      phoneNumber: string;
    };
    dashboard: {
      title: string;
      welcome: string;
      statistics: string;
      recentActivities: string;
      quickActions: string;
      overview: string;
      totalRecords: string;
      pendingTasks: string;
      completedTasks: string;
      alerts: string;
    };
    supplies: {
      title: string;
      medicineSupplies: string;
      nutritionSupplies: string;
      availableStock: string;
      outOfStock: string;
      lowStock: string;
      addSupply: string;
      updateStock: string;
      stockLevel: string;
      lastUpdated: string;
      expiryDate: string;
    };
    contact: {
      title: string;
      getInTouch: string;
      name: string;
      email: string;
      subject: string;
      message: string;
      sendMessage: string;
      contactInfo: string;
      address: string;
      phone: string;
      officeHours: string;
    };
    help: {
      title: string;
      faq: string;
      documentation: string;
      tutorials: string;
      contactSupport: string;
      searchHelp: string;
      userGuide: string;
      videoTutorials: string;
    };
    ncd: {
      title: string;
      nonCommunicableDiseases: string;
      diabetes: string;
      hypertension: string;
      cardiovascular: string;
      respiratory: string;
      addRecord: string;
      viewRecords: string;
      patientName: string;
      dateOfVisit: string;
      diagnosis: string;
      treatment: string;
    };
    preview: {
      title: string;
      dataPreview: string;
      recordDetails: string;
      printReport: string;
      downloadReport: string;
      shareReport: string;
    };
    profile: {
      title: string;
      personalInfo: string;
      updateProfile: string;
      changePassword: string;
      settings: string;
      language: string;
      notifications: string;
      privacy: string;
    };
    errors: {
      generic: string;
      notFound: string;
      unauthorized: string;
      serverError: string;
      networkError: string;
      validationError: string;
      required: string;
    };
    success: {
      saved: string;
      updated: string;
      deleted: string;
      created: string;
    };
    app: {
      name: string;
      tagline: string;
      description: string;
      footer: string;
    };
  }
}

export type { Locale };
