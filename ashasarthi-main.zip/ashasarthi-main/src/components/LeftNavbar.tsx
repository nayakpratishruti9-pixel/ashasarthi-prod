"use client";
import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ChevronRight,
  ClipboardList,
  HeartPulse,
  Menu,
  Package,
  Syringe,
  X,
} from "lucide-react";
import { useTranslations } from "next-intl";
import { useEffect, useState } from "react";

interface LeftNavLink {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}



const LeftNavbar = () => {
  const pathname = usePathname();
  const t = useTranslations("home");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks: LeftNavLink[] = [
  {
    label: t("medicinesTitle"),
    href: "/supplies",
    icon: Package,
  },
  {
    label: t("ashaKitTitle"),
    href: "/dashboard",
    icon: ClipboardList,
  },
  {
    label: t("ncdDataTitle"),
    href: "/ncd-data",
    icon: HeartPulse,
  },
  {
    label: t("vaccinationTitle"),
    href: "/vaccination-data",
    icon: Syringe,
  },
];

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!isMobileMenuOpen) {
      return;
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setIsMobileMenuOpen(false);
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    document.body.style.overflow = "hidden";

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [isMobileMenuOpen]);

  const navigationContent = (
    <>
      <nav aria-label="Health records navigation" className="flex-1">
        <p className="mb-3 px-3 text-xs font-semibold uppercase tracking-wider text-gray-400">
          Quick access
        </p>
        <ul className="space-y-1.5">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive =
              pathname === link.href || pathname.startsWith(`${link.href}/`);

            return (
              <li key={link.href}>
                <Link
                  href={link.href}
                  aria-current={isActive ? "page" : undefined}
                  className={`group flex items-center justify-between rounded-xl px-3 py-3 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-orange-100 text-orange-700 shadow-sm"
                      : "text-gray-600 hover:bg-orange-50 hover:text-orange-600"
                  }`}
                >
                  <span className="flex min-w-0 items-center gap-3">
                    <Icon
                      className={`h-5 w-5 shrink-0 ${
                        isActive
                          ? "text-orange-600"
                          : "text-gray-400 group-hover:text-orange-500"
                      }`}
                      aria-hidden="true"
                    />
                    <span className="truncate">{link.label}</span>
                  </span>
                  <ChevronRight
                    className={`h-4 w-4 shrink-0 transition-transform ${
                      isActive
                        ? "text-orange-500"
                        : "text-gray-300 group-hover:translate-x-0.5 group-hover:text-orange-400"
                    }`}
                    aria-hidden="true"
                  />
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="rounded-xl border border-orange-100 bg-orange-50 p-3 text-xs leading-5 text-orange-800">
        Keep patient records and supplies up to date for better care.
      </div>
    </>
  );

  return (
    <>
      <button
        type="button"
        onClick={() => setIsMobileMenuOpen(true)}
        aria-label="Open health records menu"
        aria-expanded={isMobileMenuOpen}
        className="fixed left-0 top-0 z-40 rounded-xl border border-orange-100 bg-white p-3 text-orange-600 shadow-lg transition hover:bg-orange-50 md:hidden"
      >
        <Menu className="h-5 w-5" aria-hidden="true" />
      </button>

      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 z-50 bg-gray-900/40 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed bottom-0 left-0 top-0 z-[60] flex w-72 transform flex-col border-r border-orange-100 bg-white p-4 shadow-2xl transition-transform duration-300 md:hidden ${
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        }`}
        aria-label="Mobile health records menu"
      >
        <div className="mb-6 flex items-center justify-between border-b border-orange-100 pb-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-orange-600">
              Health records
            </p>
            <h2 className="mt-1 text-lg font-bold text-gray-900">Asha Sarthi</h2>
          </div>
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(false)}
            aria-label="Close health records menu"
            className="rounded-lg p-2 text-gray-500 transition hover:bg-orange-50 hover:text-orange-600"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
        <div className="flex min-h-0 flex-1 flex-col">
          {navigationContent}
        </div>
      </aside>

      <aside className="hidden min-h-[calc(100vh-64px)] w-72 shrink-0 border-r border-orange-100 bg-white md:block">
      <div className="sticky top-16 flex min-h-[calc(100vh-64px)] flex-col p-4">
        {navigationContent}
      </div>
      </aside>
    </>
  );
};

export default LeftNavbar;
