"use client";

import { useState, useEffect, useRef } from "react";
import { Globe, Check, ChevronDown } from "lucide-react";
import { locales, defaultLocale, type Locale } from "@/../i18n";

// Locale display names with native language names
function getLocaleDisplayName(locale: Locale): string {
  const names: Record<Locale, string> = {
    en: "English",
    hi: "हिन्दी",
    or: "ଓଡ଼ିଆ",
    es: "Español",    ta: 'தமிழ்',
    te: 'తెలుగు',
    ml: 'മലയാളം',  };
  return names[locale];
}

export default function LanguageSwitcher() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentLocale, setCurrentLocale] = useState<Locale>(defaultLocale);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Load current locale from cookie on mount
  useEffect(() => {
    const cookieLocale = document.cookie
      .split("; ")
      .find((row) => row.startsWith("NEXT_LOCALE="))
      ?.split("=")[1] as Locale | undefined;

    if (cookieLocale && locales.includes(cookieLocale)) {
      setCurrentLocale(cookieLocale);
    }
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }
  }, [isOpen]);

  const switchLanguage = async (newLocale: Locale) => {
    if (isTransitioning || newLocale === currentLocale) {
      setIsOpen(false);
      return;
    }

    setIsTransitioning(true);

    // Set cookie with 1 year expiry
    document.cookie = `NEXT_LOCALE=${newLocale}; path=/; max-age=31536000; SameSite=Lax`;
    setCurrentLocale(newLocale);
    setIsOpen(false);

    // Small delay before reload to ensure cookie is set
    await new Promise((resolve) => setTimeout(resolve, 100));
    window.location.reload();
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Language Switcher Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        disabled={isTransitioning}
        className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-orange-50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        aria-label="Change language"
      >
        <Globe size={18} className="text-orange-600" />
        <span className="text-sm font-medium text-gray-700">
          {getLocaleDisplayName(currentLocale)}
        </span>
        <ChevronDown
          size={16}
          className={`text-gray-500 transition-transform duration-200 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50 animate-in fade-in slide-in-from-top-2 duration-200">
          {locales.map((locale) => (
            <button
              key={locale}
              onClick={() => switchLanguage(locale)}
              disabled={isTransitioning}
              className={`w-full px-4 py-2 text-left hover:bg-orange-50 flex items-center gap-3 transition-colors duration-150 disabled:opacity-50 disabled:cursor-not-allowed ${
                locale === currentLocale ? "bg-orange-50" : ""
              }`}
            >
              <span className="text-sm font-medium text-gray-700 flex-1">
                {getLocaleDisplayName(locale)}
              </span>
              {locale === currentLocale && (
                <Check size={16} className="text-orange-600" />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
