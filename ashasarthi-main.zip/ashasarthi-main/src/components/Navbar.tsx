"use client";
import { useState, useEffect } from "react";
import {
  Home,
  LayoutDashboard,
  Phone,
  HelpCircle,
  Heart,
  Grape,
  SquareUser,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { handleSignOut } from "@/app/content/useAuth";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { useTranslations } from "next-intl";

interface NavLink {
  name: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  translationKey: string;
}

const Navbar = () => {
  const [activeLink, setActiveLink] = useState("/");
  const pathname = usePathname();
  const t = useTranslations('navigation');
  const tApp = useTranslations('app');

  const navLinks: NavLink[] = [
    { name: "Home", href: "/", icon: Home, translationKey: "home" },
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard, translationKey: "dashboard" },
    { name: "Supplies", href: "/supplies", icon: Grape, translationKey: "supplies" },
    // { name: "Contact", href: "/contact", icon: Phone, translationKey: "contact" },
    { name: "Help", href: "/help", icon: HelpCircle, translationKey: "help" },
    { name: "Preview", href: "/preview", icon: SquareUser, translationKey: "preview" },
  ];

  useEffect(() => {
    setActiveLink(pathname);
  }, [pathname]);

  return (
    <>
      {/* Desktop Navbar (Top) */}
      <nav className="bg-white shadow-lg border-b-2 border-orange-100 sticky top-0 z-50 hidden md:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center">
              <div className="flex items-center space-x-2">
                {/* <div className="h-10 w-10 bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                  <Heart className="h-6 w-6 text-white" />
                </div> */}
                <div className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-orange-700 bg-clip-text text-transparent">
                  {tApp('name')}
                </div>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <div className="ml-10 flex items-baseline space-x-1">
              {navLinks.map((link) => {
                const IconComponent = link.icon;
                const isActive = activeLink === link.href;
                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                      isActive
                        ? "bg-orange-100 text-orange-700 shadow-sm"
                        : "text-gray-600 hover:text-orange-600 hover:bg-orange-50"
                    }`}
                  >
                    <IconComponent className="h-4 w-4" />
                    <span className="capitalize">{t(link.translationKey)}</span>
                  </Link>
                );
              })}
            </div>

            {/* User Actions */}
            <div className="flex items-center space-x-4">
              {/* Language Switcher */}
              <LanguageSwitcher />
              
              <button
                onClick={handleSignOut}
                className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition duration-200 shadow-md hover:shadow-lg transform hover:scale-105"
              >
                {t('signOut')}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navbar */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-orange-100 shadow-lg md:hidden">
        <div className="flex justify-around items-center h-16">
          {navLinks.map((link) => {
            const IconComponent = link.icon;
            const isActive = activeLink === link.href;
            return (
              <Link
                key={link.name}
                href={link.href}
                className={`flex flex-col items-center justify-center text-xs ${
                  isActive
                    ? "text-orange-600"
                    : "text-gray-500 hover:text-orange-600"
                }`}
              >
                <IconComponent className="h-5 w-5 mb-1" />
                <span>{t(link.translationKey)}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
};

export default Navbar;
