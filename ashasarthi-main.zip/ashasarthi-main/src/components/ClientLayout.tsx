"use client";
import Navbar from "./Navbar";
import LeftNavbar from "./LeftNavbar";
import React from "react";
import { usePathname } from "next/navigation";

export default function ClientLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
    const pathname = usePathname();
    const denyNavbar = ["/signin", "/signup"];
  return(
  <div>
    {denyNavbar.includes(pathname) ? null : <Navbar />}
    {denyNavbar.includes(pathname) ? (
      children
    ) : (
      <div className="flex">
        <LeftNavbar />
        <main className="min-w-0 flex-1">{children}</main>
      </div>
    )}
    </div>);
}
