'use client';

import { ReactNode, useEffect, useState } from 'react';
import { NextIntlClientProvider } from 'next-intl';
import { defaultLocale, locales, type Locale } from '@/../i18n';

type Messages = Record<string, Record<string, string> | string>;

interface IntlProviderProps {
  children: ReactNode;
  initialMessages: Messages;
}

export default function IntlProvider({ 
  children, 
  initialMessages 
}: IntlProviderProps) {
  const [locale, setLocale] = useState<Locale>(defaultLocale);
  const [messages, setMessages] = useState(initialMessages);

  useEffect(() => {
    // Read locale from cookie
    const cookieLocale = document.cookie
      .split('; ')
      .find(row => row.startsWith('NEXT_LOCALE='))
      ?.split('=')[1] as Locale | undefined;

    if (cookieLocale && locales.includes(cookieLocale) && cookieLocale !== locale) {
      // Dynamically import the new language messages
      import(`@/../messages/${cookieLocale}.json`)
        .then(module => {
          setMessages(module.default);
          setLocale(cookieLocale);
        })
        .catch(error => {
          console.error('Failed to load language:', error);
        });
    }
  }, [locale]);

  return (
    <NextIntlClientProvider 
      messages={messages} 
      locale={locale}
      timeZone="UTC"
      now={new Date()}
    >
      {children}
    </NextIntlClientProvider>
  );
}
