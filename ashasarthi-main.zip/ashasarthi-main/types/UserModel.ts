type UserModel = {
    id: string;
    name: string;
    email: string;
    password: string;
    role: "admin" | "asha" | "anm" | "awcs";
}

export type { UserModel };