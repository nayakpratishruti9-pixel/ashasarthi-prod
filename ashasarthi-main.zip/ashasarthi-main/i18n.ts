import { getRequestConfig } from 'next-intl/server';
import en from './messages/en.json';
import es from './messages/es.json';
import hi from './messages/hi.json';
import or from './messages/or.json';
import ta from './messages/ta.json';
import te from './messages/te.json';
import ml from './messages/ml.json';
// import fr from './messages/fr.json';
// import kn from './messages/kn.json';
// import mr from './messages/mr.json';

// List of supported locales
export const locales = ['en', 'es', 'hi', 'or', 'ta', 'te', 'ml'] as const;
export type Locale = (typeof locales)[number];

// Default locale
export const defaultLocale: Locale = 'en';

// Static message imports
const messages = {
  en,
  es,
  hi,
  or,
  ta,
  te,
  ml,
  // fr,
  // kn,
  // mr,
};

export default getRequestConfig(async ({ requestLocale }) => {
  // Support both server and client-side locale resolution
  let locale = await requestLocale;
  
  // Also check for locale from cookies and headers
  if (!locale) {
    try {
      const { headers, cookies } = await import('next/headers');
      
      // First try cookie
      const cookieStore = await cookies();
      const cookieLocale = cookieStore.get('NEXT_LOCALE')?.value;
      if (cookieLocale && locales.includes(cookieLocale as Locale)) {
        locale = cookieLocale;
      } else {
        // Then try header (set by middleware)
        const headerStore = await headers();
        const headerLocale = headerStore.get('x-next-intl-locale');
        if (headerLocale && locales.includes(headerLocale as Locale)) {
          locale = headerLocale;
        }
      }
    } catch (error) {
      // Server-side only features might not be available in all contexts
      console.log('Could not read cookies/headers for locale detection:', error);
    }
  }
  
  // Fallback to default locale if not found
  if (!locale || !locales.includes(locale as Locale)) {
    locale = defaultLocale;
  }
  
  return {
    locale,
    messages: messages[locale as Locale],
    timeZone: 'UTC',
    now: new Date(),
    formats: {
      dateTime: {
        short: {
          day: 'numeric',
          month: 'short',
          year: 'numeric'
        }
      }
    }
  };
});
